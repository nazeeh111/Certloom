Certloom portable verification
==============================

With a separately installed trusted Certloom, run:
  certloom verify-bundle certloom-proof.zip

The ZIP member checker is not executed by verify-bundle. If you choose to extract and run checker.py, first establish trust in that file; then run python3 -I -S checker.py certificate.json and compare its output with verification.json. Exit 0 means an enclosure is certified, 3 means the proof premise failed, 2 means invalid input or a file error. Threshold verdicts remain separate.

Certificate SHA-256: 8001aaf16bc86b55ed4912ec18ab9bdaece1e7ed70c26a52ace6c0c0e6175998
Checker SHA-256: 9eb5e9a31987cf7c09ac2f2f8fd2f938931fab6998c8da8670034cdd5e35fb76
These identify bytes, not source authenticity.

The claim concerns only the exact stored binary64 linear equations. It does not establish physical model correctness, measurement quality or a solver's reliability. A certified interval may be wide; a threshold may remain undecidable.

Source and method: https://github.com/nazeeh111/Certloom
Original code: MIT. Mathematical foundations and scope are documented in the repository.
